from publicador import publicar_recuento

publicar_recuento()
