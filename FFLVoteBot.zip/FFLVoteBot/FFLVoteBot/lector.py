import re
import time
from urllib.parse import urlparse

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    StaleElementReferenceException,
    TimeoutException,
    NoSuchElementException,
    WebDriverException,
)

from configuracion import (
    URL_TEMA,
    ID_PARTIDA,
    CARPETA_PERFIL,
    SELECTOR_POSTS,
    SELECTOR_TEXTO,
    HEADLESS,
    DEBUG,
    URL_INICIO_FASE,
    POST_INICIO_FASE,
)

from estado import (
    iniciar_partida_si_corresponde,
    obtener_ultimo_post,
    obtener_ultima_pagina,
    registrar_ultimo_post,
    registrar_ultima_pagina,
    configurar_inicio_fase,
)


# ==========================================
# CONFIGURACIÓN INTERNA
# ==========================================

MAX_REINTENTOS_POST = 3
ESPERA_REINTENTO = 0.5


# ==========================================
# CREAR NAVEGADOR
# ==========================================

def crear_driver():

    opciones = Options()

    opciones.add_argument(
        f"--user-data-dir={CARPETA_PERFIL}"
    )

    if HEADLESS:
        opciones.add_argument(
            "--headless=new"
        )

    opciones.add_argument(
        "--start-maximized"
    )

    return webdriver.Chrome(
        options=opciones
    )




# ==========================================
# INICIO DE SESIÓN MANUAL EN CHROMIUM
# ==========================================

def preparar_sesion_inicial():
    """
    Abre Chromium antes de comenzar el bot y espera a que el usuario
    inicie sesión manualmente en Fanficslandia.

    Al usar el perfil persistente, las cookies de sesión quedan guardadas
    para las siguientes aperturas del navegador. El usuario confirma en
    la consola cuando terminó de iniciar sesión.
    """
    driver = crear_driver()
    try:
        destino = URL_INICIO_FASE or URL_TEMA
        print("\n===============================================")
        print("INICIO DE SESIÓN EN FANFICSLANDIA")
        print("===============================================")
        print("Chromium está abierto. Iniciá sesión en Fanficslandia.")
        print("Cuando termines, volvé a esta consola y presioná ENTER.")
        print("El bot no empezará a leer ni cerrará Chromium hasta que confirmes.")
        driver.get(destino)
        try:
            input("\nPresioná ENTER cuando hayas terminado de iniciar sesión...")
        except EOFError:
            # Si se ejecuta sin entrada interactiva, damos tiempo para el login.
            print("No hay consola interactiva; esperando 120 segundos para iniciar sesión...")
            time.sleep(120)
    except KeyboardInterrupt:
        raise
    finally:
        try:
            driver.quit()
        except Exception:
            pass


# ==========================================
# ESPERAR POSTS
# ==========================================

def esperar_posts(driver):

    try:

        WebDriverWait(
            driver,
            10
        ).until(

            EC.presence_of_element_located(
                (
                    By.CSS_SELECTOR,
                    SELECTOR_POSTS
                )
            )

        )

        return True

    except TimeoutException:

        if DEBUG:
            print(
                "No aparecieron posts dentro "
                "del tiempo esperado."
            )

        return False


# ==========================================
# EXTRAER TEXTO SIN CITAS
# ==========================================

def extraer_texto_limpio(driver, post):

    elemento = post.find_element(
        By.CSS_SELECTOR,
        SELECTOR_TEXTO
    )

    texto = driver.execute_script(
        """
        const copia = arguments[0].cloneNode(true);

        copia.querySelectorAll(
            'blockquote.quoteContainer, blockquote.bbCodeBlock--quote, .bbCodeBlock--quote'
        ).forEach(
            c => c.remove()
        );

        return copia.innerText || '';
        """,
        elemento
    )

    return (
        texto or ""
    ).strip()


# ==========================================
# OBTENER NÚMERO DE PÁGINA DESDE URL
# ==========================================

def numero_pagina_desde_url(url):

    path = urlparse(
        url
    ).path.rstrip("/")

    match = re.search(
        r"/page-(\d+)$",
        path
    )

    if match:

        return int(
            match.group(1)
        )

    return 1


# ==========================================
# DETECTAR ÚLTIMA PÁGINA DEL TEMA
# ==========================================

def obtener_ultima_pagina_tema(driver):

    """
    Busca únicamente enlaces /page-N que
    pertenezcan al tema actual.

    No usa números visibles de otros enlaces
    de la página.
    """

    paginas = {1}

    tema_base = URL_TEMA.rstrip("/")

    try:

        enlaces = driver.execute_script(
            """
            return Array.from(
                document.querySelectorAll(
                    'a[href]'
                )
            ).map(
                a => a.href || ''
            );
            """
        )

    except WebDriverException as error:

        if DEBUG:

            print(
                "No se pudieron inspeccionar "
                "los enlaces de paginación:",
                error
            )

        return 1

    for href in enlaces:

        if not href:
            continue

        # Sólo enlaces pertenecientes
        # al mismo tema.
        if not href.startswith(
            tema_base
        ):
            continue

        match = re.search(
            r"/page-(\d+)(?:/|\?|#|$)",
            href
        )

        if not match:
            continue

        try:

            numero = int(
                match.group(1)
            )

        except ValueError:
            continue

        if numero >= 1:

            paginas.add(
                numero
            )

    ultima = max(
        paginas
    )

    if DEBUG:

        print(
            "Páginas encontradas en el tema:",
            sorted(paginas)
        )

    return ultima


# ==========================================
# CREAR URL DE PÁGINA
# ==========================================

def url_pagina(numero):

    if numero == 1:

        return URL_TEMA

    return (
        f"{URL_TEMA.rstrip('/')}"
        f"/page-{numero}"
    )


# ==========================================
# OBTENER IDS DE POSTS
# ==========================================

def obtener_ids_posts(driver):

    ids = driver.execute_script(
        """
        const selector = arguments[0];

        return Array.from(
            document.querySelectorAll(selector)
        )
        .map(
            e => e.id || ''
        )
        .filter(
            id => id.startsWith('post-')
        );
        """,
        SELECTOR_POSTS
    )

    resultado = []

    for identificador in ids:

        try:

            numero = int(
                identificador.replace(
                    "post-",
                    "",
                    1
                )
            )

            resultado.append(
                numero
            )

        except ValueError:
            pass

    return sorted(
        set(resultado)
    )


# ==========================================
# LEER POST
# ==========================================

def leer_post(
    driver,
    post_id,
    pagina
):

    for intento in range(
        1,
        MAX_REINTENTOS_POST + 1
    ):

        try:

            post = WebDriverWait(
                driver,
                5
            ).until(

                EC.presence_of_element_located(
                    (
                        By.ID,
                        f"post-{post_id}"
                    )
                )

            )

            return {

                "id": post_id,

                "autor": post.get_attribute(
                    "data-author"
                ),

                "mensaje": extraer_texto_limpio(
                    driver,
                    post
                ),

                "pagina": pagina,

            }

        except (
            StaleElementReferenceException,
            TimeoutException,
            NoSuchElementException,
            WebDriverException
        ) as error:

            if DEBUG:

                print(
                    f"Reintento "
                    f"{intento}/"
                    f"{MAX_REINTENTOS_POST} "
                    f"para post "
                    f"{post_id}:",
                    error
                )

            time.sleep(
                ESPERA_REINTENTO
            )

    return None


# ==========================================
# LEER POSTS NUEVOS
# ==========================================

def leer_posts_nuevos():

    iniciar_partida_si_corresponde(
        ID_PARTIDA,
        URL_TEMA
    )

    pagina_ancla = numero_pagina_desde_url(URL_INICIO_FASE) if URL_INICIO_FASE else 1
    configurar_inicio_fase(URL_INICIO_FASE, POST_INICIO_FASE, pagina_ancla)

    driver = crear_driver()

    nuevos = []

    ultimo_post_encontrado = 0

    try:

        # ==================================
        # CARGAR MEMORIA
        # ==================================

        ultimo_post = (
            obtener_ultimo_post()
        )

        pagina_guardada = (
            obtener_ultima_pagina()
        )

        # ==================================
        # ABRIR TEMA
        # ==================================

        driver.get(
            URL_INICIO_FASE or URL_TEMA
        )

        if not esperar_posts(
            driver
        ):

            raise RuntimeError(
                "No se pudieron cargar "
                "los posts del tema."
            )

        # ==================================
        # DETECTAR ÚLTIMA PÁGINA
        # ==================================

        ultima = (
            obtener_ultima_pagina_tema(
                driver
            )
        )

        # ==================================
        # DETERMINAR PÁGINA INICIAL
        # ==================================

        inicio_guardado = min(max(1, pagina_guardada), ultima)
        if URL_INICIO_FASE:
            inicio = min(max(1, pagina_ancla, inicio_guardado), ultima)
        else:
            inicio = inicio_guardado

        if DEBUG:

            print(
                "Último post leído:",
                ultimo_post
            )

            print(
                "Página inicial:",
                inicio
            )

            print(
                "Última página real detectada:",
                ultima
            )

        # ==================================
        # RECORRER PÁGINAS
        # ==================================

        ultima_confirmada = inicio

        for pagina in range(
            inicio,
            ultima + 1
        ):

            solicitada = (
                url_pagina(
                    pagina
                )
            )

            driver.get(
                solicitada
            )

            # ------------------------------
            # Esperar posts
            # ------------------------------

            if not esperar_posts(
                driver
            ):

                print(
                    f"Página {pagina} "
                    "sin posts; "
                    "se detiene el recorrido."
                )

                break

            # ------------------------------
            # Comprobar redirección
            # ------------------------------

            pagina_real = (
                numero_pagina_desde_url(
                    driver.current_url
                )
            )

            if pagina_real != pagina:

                print(
                    f"Página {pagina} "
                    "no existe: "
                    "el sitio redirigió a "
                    f"página {pagina_real}. "
                    "Se detiene."
                )

                break

            ultima_confirmada = pagina

            if DEBUG:

                print(
                    "Leyendo página:",
                    pagina
                )

            # ==================================
            # OBTENER POSTS
            # ==================================

            ids_posts = (
                obtener_ids_posts(
                    driver
                )
            )

            if DEBUG:

                print(
                    "Posts encontrados:",
                    len(ids_posts)
                )

            # ==================================
            # PROCESAR POSTS NUEVOS
            # ==================================

            for post_id in ids_posts:

                # El post del GM marca el inicio de fase; no se procesan
                # ni ese mensaje ni publicaciones anteriores.
                if POST_INICIO_FASE and post_id <= POST_INICIO_FASE:
                    continue

                if post_id <= ultimo_post:
                    continue

                datos = leer_post(
                    driver,
                    post_id,
                    pagina
                )

                if datos is None:
                    continue

                nuevos.append(
                    datos
                )

                ultimo_post_encontrado = max(
                    ultimo_post_encontrado,
                    post_id
                )

                if DEBUG:

                    print(
                        "Post nuevo leído:",
                        post_id
                    )

        # ==================================
        # GUARDAR MEMORIA
        # ==================================

        registrar_ultima_pagina(
            ultima_confirmada
        )

        if ultimo_post_encontrado:

            registrar_ultimo_post(
                ultimo_post_encontrado
            )

    finally:

        try:

            driver.quit()

        except Exception:
            pass

    # ======================================
    # RESULTADO
    # ======================================

    if DEBUG:

        print(
            "Posts nuevos:",
            len(nuevos)
        )

    return nuevos
