import json
import time
from configuracion import (
    ARCHIVO_ESTADO,
    ARCHIVO_VOTOS,
    ARCHIVO_RECUENTO,
    ARCHIVO_TIEMPOS,
    DEBUG,
)

ESTADO_INICIAL = {
    "id_partida": "",
    "url": "",
    "ultimo_post": 0,
    "ultima_pagina": 1,
    "inicio_partida": 0,
    "ultimo_recuento_publicado": 0,
    "url_inicio_fase": "",
    "post_inicio_fase": 0,
}

def guardar_estado(estado):
    with open(ARCHIVO_ESTADO, "w", encoding="utf-8") as f:
        json.dump(estado, f, indent=4, ensure_ascii=False)

def crear_estado_si_no_existe():
    if not ARCHIVO_ESTADO.exists():
        guardar_estado(ESTADO_INICIAL.copy())

def cargar_estado():
    crear_estado_si_no_existe()
    try:
        with open(ARCHIVO_ESTADO, "r", encoding="utf-8") as f:
            estado = json.load(f)
        if not isinstance(estado, dict):
            raise ValueError("estado.json no contiene un objeto JSON")
    except (json.JSONDecodeError, OSError, ValueError) as e:
        raise RuntimeError(f"No se pudo leer estado.json: {e}") from e

    if "posts_leidos" in estado:
        posts = estado.get("posts_leidos") or []
        estado["ultimo_post"] = max(posts) if posts else 0
        estado.pop("posts_leidos", None)

    for clave, valor in ESTADO_INICIAL.items():
        estado.setdefault(clave, valor)

    guardar_estado(estado)
    return estado

def _vaciar_archivo_json(ruta, contenido):
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(contenido, f, indent=4, ensure_ascii=False)

def iniciar_partida_si_corresponde(id_partida, url):
    estado = cargar_estado()
    id_anterior = str(estado.get("id_partida", "")).strip()
    url_anterior = str(estado.get("url", "")).strip()

    # Nueva mafia: cambia el ID de partida.
    if id_anterior != id_partida:
        _vaciar_archivo_json(ARCHIVO_VOTOS, {})
        _vaciar_archivo_json(ARCHIVO_TIEMPOS, {})
        ARCHIVO_RECUENTO.write_text("", encoding="utf-8")

        ahora = int(time.time())
        nuevo = ESTADO_INICIAL.copy()
        nuevo.update({
            "id_partida": id_partida,
            "url": url,
            "inicio_partida": ahora,
            "ultimo_recuento_publicado": ahora,
        })
        guardar_estado(nuevo)

        if DEBUG:
            print(f"Nueva partida detectada: {id_partida}. Estado temporal reiniciado.")
        return True

    # Misma mafia, nueva URL/día: reinicia sólo la memoria del lector.
    if url_anterior != url:
        estado["url"] = url
        estado["ultimo_post"] = 0
        estado["ultima_pagina"] = 1
        guardar_estado(estado)

        if DEBUG:
            print("Nuevo tema/día detectado. Se reinició únicamente la memoria de lectura.")
        return True

    return False

def configurar_inicio_fase(url_inicio, post_id, pagina):
    """Guarda el ancla de la fase y reinicia el cursor si cambió."""
    estado = cargar_estado()
    url_inicio = str(url_inicio or "").strip()
    post_id = int(post_id or 0)
    pagina = max(1, int(pagina or 1))

    if (estado.get("url_inicio_fase", "") != url_inicio
            or int(estado.get("post_inicio_fase", 0) or 0) != post_id):
        estado["url_inicio_fase"] = url_inicio
        estado["post_inicio_fase"] = post_id
        estado["ultimo_post"] = post_id
        estado["ultima_pagina"] = pagina
        guardar_estado(estado)

        # Una fase nueva debe arrancar sin votos heredados de la fase anterior.
        _vaciar_archivo_json(ARCHIVO_VOTOS, {})
        _vaciar_archivo_json(ARCHIVO_TIEMPOS, {})
        ARCHIVO_RECUENTO.write_text("", encoding="utf-8")

        if DEBUG:
            print(f"Inicio de fase configurado: post #{post_id or 'no indicado'}, página {pagina}. Memoria de votos reiniciada.")
        return True
    return False


def obtener_ultimo_post():
    return int(cargar_estado().get("ultimo_post", 0))

def registrar_ultimo_post(post_id):
    estado = cargar_estado()
    if post_id > int(estado.get("ultimo_post", 0)):
        estado["ultimo_post"] = int(post_id)
        guardar_estado(estado)

def obtener_ultima_pagina():
    return max(1, int(cargar_estado().get("ultima_pagina", 1)))

def registrar_ultima_pagina(pagina):
    estado = cargar_estado()
    estado["ultima_pagina"] = max(1, int(pagina))
    guardar_estado(estado)

def obtener_ultimo_recuento_publicado():
    return int(cargar_estado().get("ultimo_recuento_publicado", 0))

def registrar_publicacion():
    estado = cargar_estado()
    estado["ultimo_recuento_publicado"] = int(time.time())
    guardar_estado(estado)

def reiniciar_estado():
    guardar_estado(ESTADO_INICIAL.copy())
    if DEBUG:
        print("Estado de lectura reiniciado. La próxima ejecución detectará la partida configurada.")
