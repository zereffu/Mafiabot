# ==========================================
# instalar.py
# Instalador del FFLVoteBot
# Crea los archivos necesarios si no existen.
# ==========================================

import json
from pathlib import Path


BASE = Path(__file__).parent


ARCHIVOS = {

    "estado.json": {
        "url": "",
        "posts_leidos": [],
        "ultimo_recuento_publicado": 0
    },

    "votos.json": {},

    "jugadores.json": {
        "jugadores": []
    },

    "partida.json": {
        "fase": "dia",
        "numero_dia": 1,
        "jugadores_vivos": []
    },

    "tiempos.json": {},

    "recuento.txt": ""
}


print()
print("=================================")
print(" Instalador FFLVoteBot ")
print("=================================")
print()


for nombre, contenido in ARCHIVOS.items():

    ruta = BASE / nombre

    if ruta.exists():

        print(f"[OK] {nombre} ya existe.")
        continue

    if nombre.endswith(".txt"):

        ruta.write_text(
            contenido,
            encoding="utf-8"
        )

    else:

        with open(
            ruta,
            "w",
            encoding="utf-8"
        ) as archivo:

            json.dump(
                contenido,
                archivo,
                indent=4,
                ensure_ascii=False
            )

    print(f"[CREADO] {nombre}")


perfil = BASE / "perfil_chrome"

if not perfil.exists():

    perfil.mkdir()

    print("[CREADA] carpeta perfil_chrome")

else:

    print("[OK] carpeta perfil_chrome")


print()
print("=================================")
print("Instalación finalizada.")
print("=================================")
print()
print("Ahora configurá:")
print()
print("- configuracion.py")
print("- jugadores.json")
print("- partida.json")
print()
print("Luego ejecutá main.py")
print()

input("ENTER para salir...")
