import json
from pathlib import Path
BASE = Path(__file__).parent
ARCHIVOS = {
    "estado.json": {"id_partida":"", "url":"", "ultimo_post":0, "ultima_pagina":1, "inicio_partida":0, "ultimo_recuento_publicado":0},
    "votos.json": {},
    "jugadores.json": {"jugadores": [], "vivos": [], "muertos": []},
    "partida.json": {"fase":"dia", "numero_dia":1, "jugadores_vivos":[], "jugadores_muertos":[]},
    "tiempos.json": {},
    "recuento.txt": "",
}
for nombre, contenido in ARCHIVOS.items():
    ruta = BASE / nombre
    if ruta.exists():
        print(f"[OK] {nombre} ya existe; no se modifica.")
        continue
    if nombre.endswith(".txt"):
        ruta.write_text(contenido, encoding="utf-8")
    else:
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump(contenido, f, indent=4, ensure_ascii=False)
    print(f"[CREADO] {nombre}")
(BASE / "perfil_chrome").mkdir(exist_ok=True)
print("Instalación finalizada.")
