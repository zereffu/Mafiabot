import json
import re
import unicodedata

from configuracion import ARCHIVO_JUGADORES, ARCHIVO_VOTOS, ARCHIVO_PARTIDA, DEBUG


def cargar_json(archivo, tipo):
    try:
        with open(archivo, "r", encoding="utf-8") as f:
            datos = json.load(f)
    except FileNotFoundError as e:
        raise RuntimeError(f"Falta el archivo {archivo.name}") from e
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"JSON inválido en {archivo.name}: línea {e.lineno}, columna {e.colno}"
        ) from e

    if not isinstance(datos, tipo):
        raise RuntimeError(f"Formato inválido en {archivo.name}")

    return datos


def normalizar(texto):
    if not texto:
        return ""

    texto = unicodedata.normalize("NFD", str(texto).strip().lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


def cargar_jugadores():
    datos = cargar_json(ARCHIVO_JUGADORES, dict)
    jugadores = datos.get("jugadores", [])

    if not isinstance(jugadores, list):
        raise RuntimeError("'jugadores' debe ser una lista en jugadores.json")

    return jugadores


def cargar_vivos():
    datos = cargar_json(ARCHIVO_PARTIDA, dict)
    vivos = datos.get("jugadores_vivos", [])

    if not isinstance(vivos, list):
        raise RuntimeError("'jugadores_vivos' debe ser una lista en partida.json")

    return vivos


def jugador_valido(nombre):
    buscado = normalizar(nombre)

    for jugador in cargar_jugadores():
        if normalizar(jugador) == buscado:
            return jugador

    return None


def esta_vivo(nombre):
    buscado = normalizar(nombre)
    return any(normalizar(j) == buscado for j in cargar_vivos())


def cargar_votos():
    return cargar_json(ARCHIVO_VOTOS, dict)


def guardar_votos(votos):
    with open(ARCHIVO_VOTOS, "w", encoding="utf-8") as f:
        json.dump(votos, f, indent=4, ensure_ascii=False)


def detectar_acciones(mensaje):
    """
    Detecta TODAS las acciones del post en el orden en que aparecen.

    Ejemplos válidos:
        Voto: Raycen
        texto... Voto: Raycen ...texto
        Desvoto
        Desvoto + Voto: Raycen en el mismo post

    El lector ya elimina las citas antes de llamar a esta función.
    """
    if not mensaje:
        return []

    jugadores = cargar_jugadores()

    mapa = {
        normalizar(jugador): jugador
        for jugador in jugadores
    }

    if not mapa:
        return []

    mensaje_sin_acentos = unicodedata.normalize("NFD", str(mensaje))
    mensaje_sin_acentos = "".join(
        c for c in mensaje_sin_acentos
        if unicodedata.category(c) != "Mn"
    )

    nombres = sorted(mapa.keys(), key=len, reverse=True)
    nombres_regex = "|".join(re.escape(nombre) for nombre in nombres)

    patron = re.compile(
        rf"\bdesvoto\b|\bvoto\s*:\s*(?P<objetivo>{nombres_regex})(?![\w])",
        re.IGNORECASE
    )

    acciones = []

    for coincidencia in patron.finditer(mensaje_sin_acentos):
        objetivo = coincidencia.group("objetivo")

        if objetivo is None:
            acciones.append(("desvoto", None))
            continue

        objetivo_real = mapa.get(normalizar(objetivo))

        if objetivo_real:
            acciones.append(("voto", objetivo_real))

    return acciones


def procesar_mensaje(autor, mensaje, post_id=None, pagina=None):
    acciones = detectar_acciones(mensaje)

    if not acciones:
        return False

    autor_real = jugador_valido(autor)

    if autor_real is None:
        if DEBUG:
            print("Autor no reconocido:", autor)
        return False

    if not esta_vivo(autor_real):
        if DEBUG:
            print("Autor no está vivo:", autor_real)
        return False

    votos = cargar_votos()
    hubo_cambios = False

    for accion, objetivo in acciones:
        if accion == "desvoto":
            if autor_real in votos:
                anterior = votos[autor_real].get("objetivo")
                del votos[autor_real]
                hubo_cambios = True

                if DEBUG:
                    print(autor_real, "quitó su voto a", anterior)

            continue

        if accion == "voto":
            objetivo_real = jugador_valido(objetivo)

            if objetivo_real is None:
                if DEBUG:
                    print("Objetivo no reconocido:", objetivo)
                continue

            if not esta_vivo(objetivo_real):
                if DEBUG:
                    print("Voto inválido:", objetivo_real, "no está vivo")
                continue

            anterior = votos.get(autor_real)

            votos[autor_real] = {
                "objetivo": objetivo_real,
                "post": post_id,
                "pagina": pagina
            }

            hubo_cambios = True

            if DEBUG:
                if anterior:
                    print(
                        autor_real,
                        "cambió su voto de",
                        anterior.get("objetivo"),
                        "a",
                        objetivo_real
                    )
                else:
                    print(autor_real, "votó a", objetivo_real)

    if hubo_cambios:
        guardar_votos(votos)

    return hubo_cambios
