# ==========================================
# configuracion.py
# Configuración del FFLVoteBot
# Valores editables en configuracion.json
# ==========================================

import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent

ARCHIVO_CONFIG = BASE / "configuracion.json"
ARCHIVO_ESTADO = BASE / "estado.json"
ARCHIVO_JUGADORES = BASE / "jugadores.json"
ARCHIVO_PARTIDA = BASE / "partida.json"
ARCHIVO_VOTOS = BASE / "votos.json"
ARCHIVO_RECUENTO = BASE / "recuento.txt"
ARCHIVO_TIEMPOS = BASE / "tiempos.json"
ARCH_VALORES_VOTO = BASE / "valores_voto.json"

CONFIG_DEFAULT = {
    "url_tema": "",
    "id_partida": "",
    "carpeta_perfil": "perfil_chrome",
    "headless": False,
    "intervalo_revision": 60,
    "intervalo_publicacion": 21600,
    "publicar_automaticamente": True,
    "debug": True
}

def crear_configuracion():
    if ARCHIVO_CONFIG.exists():
        return
    with open(ARCHIVO_CONFIG, "w", encoding="utf-8") as archivo:
        json.dump(CONFIG_DEFAULT, archivo, indent=4, ensure_ascii=False)

crear_configuracion()

try:
    with open(ARCHIVO_CONFIG, "r", encoding="utf-8") as archivo:
        CONFIG = json.load(archivo)
except json.JSONDecodeError as e:
    raise RuntimeError(
        f"JSON inválido en configuracion.json: línea {e.lineno}, columna {e.colno}"
    ) from e

URL_TEMA = str(CONFIG.get("url_tema", "")).strip()
ID_PARTIDA = str(CONFIG.get("id_partida", "")).strip()

# Post que marca el inicio de la fase actual. Se configura desde partida.json.
ARCHIVO_PARTIDA.parent.mkdir(parents=True, exist_ok=True)
try:
    with open(ARCHIVO_PARTIDA, "r", encoding="utf-8") as archivo:
        PARTIDA_CONFIG = json.load(archivo)
except (OSError, json.JSONDecodeError):
    PARTIDA_CONFIG = {}
URL_INICIO_FASE = str(PARTIDA_CONFIG.get("url_inicio_fase", "")).strip()
_match_post_inicio = re.search(r"#post-(\d+)", URL_INICIO_FASE)
POST_INICIO_FASE = int(_match_post_inicio.group(1)) if _match_post_inicio else 0

_perfil = Path(CONFIG.get("carpeta_perfil", "perfil_chrome"))
if not _perfil.is_absolute():
    _perfil = BASE / _perfil
CARPETA_PERFIL = str(_perfil.resolve())

HEADLESS = bool(CONFIG.get("headless", False))
INTERVALO_REVISION = int(CONFIG.get("intervalo_revision", 60))
INTERVALO_PUBLICACION = int(CONFIG.get("intervalo_publicacion", 21600))
PUBLICAR_AUTOMATICAMENTE = bool(CONFIG.get("publicar_automaticamente", True))
DEBUG = bool(CONFIG.get("debug", True))

SELECTOR_POSTS = "li.message"
SELECTOR_TEXTO = "blockquote.messageText"
PREFIJO_VOTO = "voto:"
PREFIJO_DESVOTO = "desvoto"
USUARIO_BOT = ""
