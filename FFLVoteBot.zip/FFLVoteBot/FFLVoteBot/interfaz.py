import json
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

BASE = Path(__file__).resolve().parent
ARCH_CONFIG = BASE / 'configuracion.json'
ARCH_PARTIDA = BASE / 'partida.json'
ARCH_JUGADORES = BASE / 'jugadores.json'
ARCH_VALORES = BASE / 'valores_voto.json'

DEFAULT_CONFIG = {
    'url_tema': '', 'id_partida': '', 'carpeta_perfil': 'perfil_chrome',
    'headless': False, 'intervalo_revision': 60,
    'intervalo_publicacion': 21600, 'publicar_automaticamente': True, 'debug': True
}
DEFAULT_PARTIDA = {'fase': 'dia', 'numero_dia': 1, 'url_inicio_fase': '', 'jugadores_vivos': [], 'jugadores_muertos': []}
DEFAULT_JUGADORES = {'jugadores': []}
DEFAULT_VALORES = {'valor_normal': 1, 'reglas': {}}


def leer_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return default.copy()


def guardar_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


class FFLVoteBotApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('FFLVoteBot | HARD UPGRADE')
        self.geometry('790x650')
        self.minsize(720, 600)
        self.configure(bg='#111827')
        self.config_data = leer_json(ARCH_CONFIG, DEFAULT_CONFIG)
        self.partida = leer_json(ARCH_PARTIDA, DEFAULT_PARTIDA)
        self.jugadores = leer_json(ARCH_JUGADORES, DEFAULT_JUGADORES)
        self.valores = leer_json(ARCH_VALORES, DEFAULT_VALORES)
        self.valores.setdefault('valor_normal', 1)
        self.valores.setdefault('reglas', {})
        self.proc = None
        self._estilos()
        self.mostrar_inicio()

    def _estilos(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('TFrame', background='#111827')
        style.configure('Panel.TFrame', background='#1f2937')
        style.configure('TLabel', background='#111827', foreground='#f9fafb', font=('Segoe UI', 10))
        style.configure('Muted.TLabel', background='#1f2937', foreground='#cbd5e1', font=('Segoe UI', 9))
        style.configure('Title.TLabel', background='#111827', foreground='#ffffff', font=('Segoe UI', 23, 'bold'))
        style.configure('Sub.TLabel', background='#111827', foreground='#9ca3af', font=('Segoe UI', 10))
        style.configure('TButton', font=('Segoe UI', 10, 'bold'), padding=10)
        style.configure('Primary.TButton', background='#2563eb', foreground='white')
        style.map('Primary.TButton', background=[('active', '#1d4ed8')])
        style.configure('Card.TButton', background='#374151', foreground='#f9fafb', anchor='w', padding=14)
        style.map('Card.TButton', background=[('active', '#4b5563')])
        style.configure('TEntry', padding=6)
        style.configure('TCombobox', padding=5)

    def limpiar(self):
        for w in self.winfo_children():
            w.destroy()

    def encabezado(self, subtitulo='Configurá la partida antes de iniciar el seguimiento de votos.'):
        ttk.Label(self, text='⚔  FFLVoteBot', style='Title.TLabel').pack(anchor='w', padx=28, pady=(22, 2))
        ttk.Label(self, text='MAFIA MANAGEMENT SYSTEM  •  HARD UPGRADE', style='Sub.TLabel').pack(anchor='w', padx=30)
        ttk.Label(self, text=subtitulo, style='Sub.TLabel').pack(anchor='w', padx=30, pady=(8, 16))

    def panel(self, parent=None):
        return ttk.Frame(parent or self, style='Panel.TFrame', padding=16)

    def mostrar_inicio(self):
        self.limpiar()
        self.encabezado()
        p = self.panel()
        p.pack(fill='x', padx=28, pady=4)
        ttk.Label(p, text='CONFIGURACIÓN DE PARTIDA', background='#1f2937', foreground='#ffffff', font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=(0, 10))
        opciones = [
            ('📂  Cargar partida', 'URL del tema, identificador y fase actual.', self.ventana_partida),
            ('👥  Cargar lista de jugadores', 'Importar o editar jugadores vivos y muertos.', self.ventana_jugadores),
            ('⚖  Cargar valor de voto', 'Valor normal y reglas por jugador: ×2, −1, 0,5 o valor personalizado.', self.ventana_valores),
        ]
        for titulo, desc, comando in opciones:
            fila = ttk.Frame(p, style='Panel.TFrame')
            fila.pack(fill='x', pady=5)
            ttk.Button(fila, text=titulo, style='Card.TButton', command=comando).pack(fill='x')
            ttk.Label(fila, text=desc, style='Muted.TLabel').pack(anchor='w', padx=8, pady=(2, 2))
        status = self.panel()
        status.pack(fill='x', padx=28, pady=12)
        ttk.Label(status, text='ESTADO DE CONFIGURACIÓN', background='#1f2937', foreground='#9ca3af', font=('Segoe UI', 9, 'bold')).pack(anchor='w', pady=(0, 8))
        url_ok = bool(self.config_data.get('url_tema', '').strip())
        id_ok = bool(self.config_data.get('id_partida', '').strip())
        vivos = self.partida.get('jugadores_vivos', [])
        todos = self.jugadores.get('jugadores', [])
        self.estado_linea(status, 'Partida', 'Configurada' if url_ok and id_ok else 'Sin cargar', url_ok and id_ok)
        self.estado_linea(status, 'Jugadores', f'{len(todos)} en lista · {len(vivos)} vivos' if todos else 'Sin cargar', bool(todos and vivos))
        self.estado_linea(status, 'Valores de voto', f"Normal: {self.valores.get('valor_normal', 1)} · {len(self.valores.get('reglas', {}))} reglas especiales", True)
        listo = url_ok and id_ok and bool(todos) and bool(vivos)
        ttk.Button(self, text='▶  INICIAR BOT', style='Primary.TButton', command=self.iniciar_bot, state='normal' if listo else 'disabled').pack(fill='x', padx=28, pady=(0, 6))
        ttk.Label(self, text='El bot conservará los módulos de lectura y publicación existentes.', style='Sub.TLabel').pack(anchor='center', pady=(0, 12))

    def estado_linea(self, parent, nombre, valor, ok):
        f = ttk.Frame(parent, style='Panel.TFrame')
        f.pack(fill='x', pady=2)
        ttk.Label(f, text=('●' if ok else '○'), background='#1f2937', foreground='#34d399' if ok else '#9ca3af').pack(side='left', padx=(0, 8))
        ttk.Label(f, text=nombre, background='#1f2937', foreground='#f9fafb').pack(side='left')
        ttk.Label(f, text=valor, style='Muted.TLabel').pack(side='right')

    def ventana_base(self, titulo):
        win = tk.Toplevel(self)
        win.title(titulo)
        win.configure(bg='#111827')
        win.transient(self)
        win.grab_set()
        win.geometry('650x600')
        win.minsize(580, 480)
        outer = ttk.Frame(win, padding=20)
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text=titulo, font=('Segoe UI', 18, 'bold')).pack(anchor='w', pady=(0, 14))
        return win, outer

    def campo(self, parent, label, valor='', width=65):
        ttk.Label(parent, text=label).pack(anchor='w', pady=(7, 3))
        var = tk.StringVar(value=str(valor))
        ent = ttk.Entry(parent, textvariable=var, width=width)
        ent.pack(fill='x')
        return var

    def ventana_partida(self):
        win, body = self.ventana_base('📂 Cargar partida')
        url = self.campo(body, 'URL del tema de Fanficslandia', self.config_data.get('url_tema', ''))
        ident = self.campo(body, 'Identificador único de esta partida', self.config_data.get('id_partida', ''))
        ttk.Label(body, text='Usá un ID distinto para cada mafia, incluso si reutilizás el mismo tema.', style='Muted.TLabel').pack(anchor='w', pady=(3, 8))
        fase_var = tk.StringVar(value=self.partida.get('fase', 'dia'))
        ttk.Label(body, text='Fase actual').pack(anchor='w', pady=(8, 3))
        ttk.Combobox(body, textvariable=fase_var, values=['dia', 'noche'], state='readonly').pack(fill='x')
        dia = self.campo(body, 'Número de día (si corresponde)', self.partida.get('numero_dia', 1))
        url_inicio = self.campo(body, 'URL del mensaje del GM que inicia esta fase (opcional)', self.partida.get('url_inicio_fase', ''))
        ttk.Label(body, text='Pegá el enlace directo al post de apertura de la fase, por ejemplo el anuncio «Día 2». El bot ignorará ese post y todos los anteriores, y contará publicaciones posteriores. Si lo dejás vacío, se mantiene el comportamiento anterior.', style='Muted.TLabel', wraplength=590).pack(anchor='w', pady=(4, 8))
        def guardar():
            if not url.get().strip() or not ident.get().strip():
                messagebox.showerror('Faltan datos', 'Completá la URL y el identificador.', parent=win); return
            self.config_data.update({'url_tema': url.get().strip(), 'id_partida': ident.get().strip()})
            try: self.partida['numero_dia'] = max(0, int(dia.get() or 0))
            except ValueError:
                messagebox.showerror('Dato inválido', 'El número de día debe ser un número entero.', parent=win); return
            self.partida['fase'] = fase_var.get()
            self.partida['url_inicio_fase'] = url_inicio.get().strip()
            if self.partida['url_inicio_fase'] and '#post-' not in self.partida['url_inicio_fase']:
                messagebox.showerror('Enlace incompleto', 'El enlace debe apuntar a un mensaje concreto e incluir #post-ID.', parent=win); return
            guardar_json(ARCH_CONFIG, self.config_data); guardar_json(ARCH_PARTIDA, self.partida)
            win.destroy(); self.mostrar_inicio()
        ttk.Button(body, text='Guardar partida', style='Primary.TButton', command=guardar).pack(fill='x', pady=18)

    def ventana_jugadores(self):
        win, body = self.ventana_base('👥 Cargar lista de jugadores')
        ttk.Label(body, text='Un nombre por línea. Podés importar un archivo .txt con la lista completa.', style='Muted.TLabel').pack(anchor='w')
        barra = ttk.Frame(body); barra.pack(fill='x', pady=8)
        ttk.Label(barra, text='Todos los jugadores').pack(side='left')
        def importar():
            path = filedialog.askopenfilename(parent=win, title='Importar lista de jugadores', filetypes=[('Texto', '*.txt'), ('JSON', '*.json'), ('Todos', '*.*')])
            if not path: return
            try:
                if path.lower().endswith('.json'):
                    data = leer_json(Path(path), {})
                    lista = data.get('jugadores', []) if isinstance(data, dict) else data
                    texto_todos.delete('1.0', 'end'); texto_todos.insert('1.0', '\n'.join(map(str, lista)))
                else:
                    texto_todos.delete('1.0', 'end'); texto_todos.insert('1.0', Path(path).read_text(encoding='utf-8-sig'))
            except Exception as e: messagebox.showerror('No se pudo importar', str(e), parent=win)
        ttk.Button(barra, text='Importar archivo…', command=importar).pack(side='right')
        texto_todos = tk.Text(body, height=8, bg='#f9fafb', fg='#111827', font=('Consolas', 10), wrap='word')
        texto_todos.pack(fill='both', expand=True)
        texto_todos.insert('1.0', '\n'.join(self.jugadores.get('jugadores', [])))
        ttk.Label(body, text='Jugadores vivos (uno por línea)').pack(anchor='w', pady=(10, 3))
        texto_vivos = tk.Text(body, height=7, bg='#f9fafb', fg='#111827', font=('Consolas', 10), wrap='word')
        texto_vivos.pack(fill='both', expand=True)
        texto_vivos.insert('1.0', '\n'.join(self.partida.get('jugadores_vivos', [])))
        ttk.Label(body, text='Los jugadores de la lista completa que no estén vivos se guardan como muertos.', style='Muted.TLabel').pack(anchor='w', pady=(5, 0))
        def guardar():
            todos = list(dict.fromkeys(x.strip() for x in texto_todos.get('1.0', 'end').splitlines() if x.strip()))
            vivos = list(dict.fromkeys(x.strip() for x in texto_vivos.get('1.0', 'end').splitlines() if x.strip()))
            if not todos or not vivos:
                messagebox.showerror('Lista incompleta', 'Ingresá al menos un jugador y un jugador vivo.', parent=win); return
            todos_norm = {x.casefold() for x in todos}
            fuera = [x for x in vivos if x.casefold() not in todos_norm]
            if fuera:
                messagebox.showerror('Jugadores no reconocidos', 'Estos nombres vivos no están en la lista completa:\n' + '\n'.join(fuera), parent=win); return
            vivos_norm = {x.casefold() for x in vivos}
            self.jugadores = {'jugadores': todos}
            self.partida['jugadores_vivos'] = vivos
            self.partida['jugadores_muertos'] = [x for x in todos if x.casefold() not in vivos_norm]
            guardar_json(ARCH_JUGADORES, self.jugadores); guardar_json(ARCH_PARTIDA, self.partida)
            win.destroy(); self.mostrar_inicio()
        ttk.Button(body, text='Guardar lista de jugadores', style='Primary.TButton', command=guardar).pack(fill='x', pady=14)

    def ventana_valores(self):
        win, body = self.ventana_base('⚖ Cargar valor de voto')
        normal = tk.StringVar(value=str(self.valores.get('valor_normal', 1)))
        ttk.Label(body, text='Valor del voto normal').pack(anchor='w', pady=(4, 3))
        ttk.Entry(body, textvariable=normal).pack(fill='x')
        ttk.Label(body, text='Podés usar enteros o decimales, por ejemplo 1, 0.5 o 1.25.', style='Muted.TLabel').pack(anchor='w', pady=(3, 8))
        ttk.Label(body, text='Reglas especiales por jugador', font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=(12, 4))
        ttk.Label(body, text='Elegí un jugador y asignale un multiplicador, un valor fijo o una de las opciones rápidas. El valor personalizado reemplaza al valor normal para ese jugador.', style='Muted.TLabel', wraplength=580).pack(anchor='w', pady=(0, 8))
        nombres = self.jugadores.get('jugadores', [])
        jugador = tk.StringVar(value=nombres[0] if nombres else '')
        regla = tk.StringVar(value='doble (×2)')
        valor_personalizado = tk.StringVar(value='0.5')
        fila = ttk.Frame(body); fila.pack(fill='x')
        ttk.Combobox(fila, textvariable=jugador, values=nombres, state='readonly', width=25).pack(side='left', fill='x', expand=True, padx=(0, 8))
        opciones_regla = ['doble (×2)', 'negativo (−1)', 'medio (0.5)', 'valor personalizado', 'normal (sin regla)']
        ttk.Combobox(fila, textvariable=regla, values=opciones_regla, state='readonly', width=22).pack(side='left')
        fila_custom = ttk.Frame(body)
        fila_custom.pack(fill='x', pady=(7, 0))
        ttk.Label(fila_custom, text='Valor personalizado (puede ser decimal o negativo):').pack(side='left', padx=(0, 8))
        ttk.Entry(fila_custom, textvariable=valor_personalizado, width=12).pack(side='left')

        lista = tk.Listbox(body, height=9, bg='#f9fafb', fg='#111827', font=('Consolas', 10), selectmode='browse')
        lista.pack(fill='both', expand=True, pady=10)
        reglas = dict(self.valores.get('reglas', {}))

        def numero_texto(valor):
            try:
                n = float(valor)
                if n.is_integer():
                    return str(int(n))
                return f'{n:g}'
            except (TypeError, ValueError):
                return str(valor)

        def etiqueta_regla(valor):
            if valor == 'doble':
                try:
                    return f'×2 (valor {numero_texto(float(normal.get().replace(",", ".")) * 2)})'
                except ValueError:
                    return '×2 del valor normal'
            if valor == 'negativo':
                return '−1 punto'
            if valor == 'medio' or valor == 0.5 or valor == '0.5':
                return '0,5 puntos'
            if valor == 'normal':
                return f'normal ({normal.get()} punto/s)'
            if isinstance(valor, (int, float)) or (isinstance(valor, str) and valor not in ('doble', 'negativo', 'normal', 'medio')):
                try:
                    return f'valor fijo {numero_texto(valor)}'
                except Exception:
                    pass
            return str(valor)

        def refrescar():
            lista.delete(0, 'end')
            for nombre in sorted(reglas, key=str.casefold):
                lista.insert('end', f'{nombre}  →  {etiqueta_regla(reglas[nombre])}')

        def asignar():
            if not jugador.get():
                messagebox.showerror('Falta jugador', 'Cargá la lista de jugadores primero.', parent=win); return
            seleccion = regla.get()
            if seleccion == 'normal (sin regla)':
                reglas.pop(jugador.get(), None)
            elif seleccion == 'doble (×2)':
                reglas[jugador.get()] = 'doble'
            elif seleccion == 'negativo (−1)':
                reglas[jugador.get()] = 'negativo'
            elif seleccion == 'medio (0.5)':
                reglas[jugador.get()] = 0.5
            else:
                try:
                    valor = float(valor_personalizado.get().strip().replace(',', '.'))
                    if not __import__('math').isfinite(valor):
                        raise ValueError
                except ValueError:
                    messagebox.showerror('Valor inválido', 'Ingresá un número válido, por ejemplo 0.5, 3 o -1.', parent=win); return
                reglas[jugador.get()] = int(valor) if valor.is_integer() else valor
            refrescar()

        def quitar():
            sel = lista.curselection()
            if sel:
                nombre = lista.get(sel[0]).split('  →  ')[0]
                reglas.pop(nombre, None); refrescar()

        acciones = ttk.Frame(body); acciones.pack(fill='x')
        ttk.Button(acciones, text='Asignar regla', command=asignar).pack(side='left')
        ttk.Button(acciones, text='Quitar regla seleccionada', command=quitar).pack(side='left', padx=8)

        def guardar():
            try:
                valor_normal = float(normal.get().strip().replace(',', '.'))
                if not __import__('math').isfinite(valor_normal):
                    raise ValueError
            except ValueError:
                messagebox.showerror('Valor normal inválido', 'Ingresá un número válido para el voto normal, por ejemplo 1 o 0.5.', parent=win); return
            self.valores = {'valor_normal': int(valor_normal) if valor_normal.is_integer() else valor_normal, 'reglas': reglas}
            guardar_json(ARCH_VALORES, self.valores)
            win.destroy(); self.mostrar_inicio()

        ttk.Button(body, text='Guardar valores de voto', style='Primary.TButton', command=guardar).pack(fill='x', pady=(8, 0))
        refrescar()

    def iniciar_bot(self):
        if self.proc and self.proc.poll() is None:
            messagebox.showinfo('Bot activo', 'El bot ya está ejecutándose.'); return
        try:
            # Validar JSON y valores antes de lanzar el proceso
            guardar_json(ARCH_CONFIG, self.config_data)
            guardar_json(ARCH_PARTIDA, self.partida)
            guardar_json(ARCH_JUGADORES, self.jugadores)
            guardar_json(ARCH_VALORES, self.valores)
            self.proc = subprocess.Popen([sys.executable, str(BASE / 'main.py')], cwd=str(BASE))
            self.mostrar_ejecucion()
        except Exception as e:
            messagebox.showerror('Error al iniciar', str(e), parent=self)

    def mostrar_ejecucion(self):
        self.limpiar(); self.encabezado('El bot está ejecutándose en un proceso independiente.')
        p = self.panel(); p.pack(fill='x', padx=28, pady=8)
        ttk.Label(p, text='BOT EN EJECUCIÓN', background='#1f2937', foreground='#34d399', font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        ttk.Label(p, text='La consola del bot mostrará las revisiones, votos detectados y publicaciones.', style='Muted.TLabel').pack(anchor='w', pady=(8, 0))
        ttk.Button(self, text='■  DETENER BOT', command=self.detener_bot).pack(fill='x', padx=28, pady=8)
        ttk.Button(self, text='Volver al menú', command=self.mostrar_inicio).pack(fill='x', padx=28)
        self.after(1000, self.comprobar_proceso)

    def comprobar_proceso(self):
        if self.proc and self.proc.poll() is not None:
            messagebox.showinfo('Bot detenido', 'El proceso del bot terminó.', parent=self)
            self.proc = None; self.mostrar_inicio()
        elif self.winfo_exists() and any(w.winfo_exists() for w in self.winfo_children()):
            self.after(1000, self.comprobar_proceso)

    def detener_bot(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try: self.proc.wait(timeout=4)
            except subprocess.TimeoutExpired: self.proc.kill()
        self.proc = None
        self.mostrar_inicio()

    def destroy(self):
        if self.proc and self.proc.poll() is None:
            if messagebox.askyesno('Bot activo', '¿Querés detener el bot y cerrar la ventana?'):
                self.detener_bot()
            else:
                return
        super().destroy()


if __name__ == '__main__':
    FFLVoteBotApp().mainloop()
