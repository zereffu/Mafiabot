import time

from configuracion import (
    INTERVALO_REVISION,
    INTERVALO_PUBLICACION,
    DEBUG,
    PUBLICAR_AUTOMATICAMENTE,
)

from lector import leer_posts_nuevos, preparar_sesion_inicial
from votos import procesar_mensaje
from recuento import actualizar_recuento
from publicador import publicar_recuento
from estado import (
    obtener_ultimo_recuento_publicado,
    registrar_publicacion,
)


def revisar_nuevos_posts():
    posts = leer_posts_nuevos()

    if not posts:
        if DEBUG:
            print("No hay posts nuevos.")
        return None

    hubo_cambios = False
    solicitar_recuento = False

    for post in posts:
        autor = post.get("autor")
        mensaje = post.get("mensaje") or ""

        if DEBUG:
            print("-------------------------")
            print(
                "Post:",
                post.get("id"),
                "Autor:",
                autor
            )
            print(mensaje)

        # ==========================================
        # SOLICITUD MANUAL DE RECUENTO
        # ==========================================

        if any(
            linea.strip().lower() == "!recuento"
            for linea in mensaje.splitlines()
        ):
            solicitar_recuento = True


        # ==========================================
        # PROCESAR VOTO / DESVOTO
        # ==========================================

        if procesar_mensaje(
            autor,
            mensaje,
            post.get("id"),
            post.get("pagina")
        ):
            hubo_cambios = True

    # ==============================================
    # GENERAR RECUENTO
    # ==============================================

    recuento = None

    if hubo_cambios or solicitar_recuento:
        recuento = actualizar_recuento()

    if recuento:
        print()
        print("===== RECUENTO ACTUAL =====")
        print(recuento)
        print("===========================")
        print()

    # ==============================================
    # !RECUENTO -> PUBLICACIÓN INMEDIATA
    # ==============================================

    if solicitar_recuento and recuento:

        if not PUBLICAR_AUTOMATICAMENTE:
            print(
                "!recuento detectado, pero "
                "PUBLICAR_AUTOMATICAMENTE está desactivado."
            )

        else:
            print(
                "!recuento detectado. "
                "Publicando recuento..."
            )

            if publicar_recuento(recuento):
                registrar_publicacion()

                print(
                    "Recuento solicitado publicado "
                    "correctamente."
                )
            else:
                print(
                    "No se pudo publicar el recuento "
                    "solicitado."
                )

    return recuento


def revisar_publicacion(recuento_actual):
    """
    Controla la publicación automática.

    Si nunca se publicó un recuento (valor 0),
    inicia el reloj sin publicar inmediatamente.

    Después publica cada INTERVALO_PUBLICACION.
    """

    if not PUBLICAR_AUTOMATICAMENTE:
        if DEBUG:
            print(
                "Publicación automática desactivada."
            )
        return

    ahora = int(time.time())

    ultima = obtener_ultimo_recuento_publicado()

    # ==============================================
    # PRIMERA EJECUCIÓN
    # ==============================================
    #
    # Si vale 0 significa que todavía no existe
    # una referencia temporal.
    #
    # Guardamos AHORA como inicio del contador,
    # pero NO publicamos todavía.
    # ==============================================

    if ultima <= 0:

        registrar_publicacion()

        if DEBUG:
            print(
                "Temporizador de publicación iniciado."
            )

            print(
                "Primer recuento automático en "
                f"{INTERVALO_PUBLICACION} segundos."
            )

        return

    # ==============================================
    # CALCULAR TIEMPO RESTANTE
    # ==============================================

    transcurrido = ahora - ultima

    restante = (
        INTERVALO_PUBLICACION
        - transcurrido
    )

    if restante > 0:

        if DEBUG:

            horas = restante // 3600

            minutos = (
                restante % 3600
            ) // 60

            segundos = restante % 60

            print(
                "Próxima publicación automática en: "
                f"{horas:02d}:"
                f"{minutos:02d}:"
                f"{segundos:02d}"
            )

        return

    # ==============================================
    # ES HORA DE PUBLICAR
    # ==============================================

    print(
        "Intervalo de publicación cumplido."
    )

    # Generamos SIEMPRE un recuento actualizado
    # desde votos.json y partida.json.
    #
    # No usamos recuento.txt como fuente.

    recuento_actual = actualizar_recuento()

    if not recuento_actual:

        print(
            "No se pudo generar el recuento. "
            "Publicación cancelada."
        )

        return

    print(
        "Publicando recuento automático..."
    )

    if publicar_recuento(
        recuento_actual
    ):

        registrar_publicacion()

        print(
            "Recuento automático publicado "
            "correctamente."
        )

    else:

        print(
            "No se pudo publicar el recuento "
            "automático."
        )


def iniciar():

    print(
        "================================="
    )

    print(
        " FFLVoteBot corregido iniciado "
    )

    print(
        "================================="
    )

    # Darle al usuario tiempo para iniciar sesión en Chromium antes de
    # comenzar las lecturas automáticas. El perfil persistente conserva
    # la sesión para los siguientes ciclos del bot.
    preparar_sesion_inicial()

    while True:

        try:

            # ======================================
            # LEER NUEVOS POSTS
            # ======================================

            revisar_nuevos_posts()

            # ======================================
            # REVISAR PUBLICACIÓN AUTOMÁTICA
            # ======================================

            revisar_publicacion(
                None
            )

        except KeyboardInterrupt:

            print()
            print(
                "Bot detenido por el usuario."
            )

            break

        except Exception as error:

            print(
                "ERROR: ciclo cancelado "
                "sin publicar:",
                error
            )

        print(
            f"Próxima revisión en "
            f"{INTERVALO_REVISION} segundos..."
        )

        time.sleep(
            INTERVALO_REVISION
        )


if __name__ == "__main__":
    iniciar()
