import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from configuracion import URL_TEMA, CARPETA_PERFIL, HEADLESS, PUBLICAR_AUTOMATICAMENTE, DEBUG

def crear_driver():
    opciones = Options()
    opciones.add_argument(f"--user-data-dir={CARPETA_PERFIL}")
    if HEADLESS:
        opciones.add_argument("--headless=new")
    opciones.add_argument("--start-maximized")
    return webdriver.Chrome(options=opciones)

def preparar_mensaje(recuento):
    if not isinstance(recuento, str) or not recuento.strip():
        raise ValueError("No hay un recuento actual válido para publicar.")
    return f"{recuento.strip()}\n\n_Actualización automática del bot_"

def publicar_recuento(recuento):
    if not PUBLICAR_AUTOMATICAMENTE:
        if DEBUG:
            print("Publicación automática desactivada.")
        return False
    try:
        mensaje = preparar_mensaje(recuento)
    except ValueError as e:
        print("Publicación cancelada:", e)
        return False

    driver = crear_driver()
    try:
        driver.get(URL_TEMA)
        time.sleep(5)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)

        editor = None
        for iframe in driver.find_elements(By.TAG_NAME, "iframe"):
            try:
                driver.switch_to.frame(iframe)
                encontrados = driver.find_elements(By.CSS_SELECTOR, "body[contenteditable='true']")
                if encontrados:
                    editor = encontrados[0]
                    break
                driver.switch_to.default_content()
            except Exception:
                driver.switch_to.default_content()

        if editor is None:
            driver.switch_to.default_content()
            encontrados = driver.find_elements(By.CSS_SELECTOR, "body[contenteditable='true']")
            if encontrados:
                editor = encontrados[0]
        if editor is None:
            raise RuntimeError("No se encontró el editor")

        driver.execute_script("""
            arguments[0].focus();
            arguments[0].innerHTML = "<p>" + arguments[1].replace(/\\n/g, "</p><p>") + "</p>";
            arguments[0].dispatchEvent(new Event("input", {bubbles:true}));
            arguments[0].dispatchEvent(new Event("change", {bubbles:true}));
        """, editor, mensaje)
        time.sleep(2)
        driver.switch_to.default_content()
        boton = WebDriverWait(driver, 20).until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, "input.button.primary[value='Responder']")
        ))
        driver.execute_script("arguments[0].click();", boton)
        time.sleep(5)
        if DEBUG:
            print("Publicación enviada.")
        return True
    except Exception as e:
        print("Error al publicar:", e)
        return False
    finally:
        driver.quit()
