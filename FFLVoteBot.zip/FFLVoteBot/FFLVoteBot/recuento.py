import json
import math
import unicodedata
from configuracion import ARCHIVO_VOTOS, ARCHIVO_RECUENTO, ARCHIVO_PARTIDA, ARCH_VALORES_VOTO, DEBUG


def cargar_json(archivo, tipo, default=None):
    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            datos = json.load(f)
    except FileNotFoundError:
        if default is not None:
            return default
        raise RuntimeError(f'Falta el archivo {archivo.name}')
    except json.JSONDecodeError as e:
        raise RuntimeError(f'JSON inválido en {archivo.name}: línea {e.lineno}, columna {e.colno}') from e
    if not isinstance(datos, tipo):
        raise RuntimeError(f'Formato inválido en {archivo.name}')
    return datos


def normalizar(texto):
    if not texto:
        return ''
    texto = unicodedata.normalize('NFD', str(texto).strip().lower())
    return ''.join(c for c in texto if unicodedata.category(c) != 'Mn')


def cargar_votos():
    return cargar_json(ARCHIVO_VOTOS, dict)


def cargar_partida():
    return cargar_json(ARCHIVO_PARTIDA, dict)


def cargar_valores():
    return cargar_json(ARCH_VALORES_VOTO, dict, {'valor_normal': 1, 'reglas': {}})


def obtener_vivos():
    vivos = cargar_partida().get('jugadores_vivos', [])
    if not isinstance(vivos, list):
        raise RuntimeError("'jugadores_vivos' debe ser una lista en partida.json")
    return {normalizar(nombre): nombre for nombre in vivos if normalizar(nombre)}


def valor_emitido(votante, valores):
    """Devuelve el valor que emite el votante; admite reglas antiguas y valores fijos."""
    reglas = valores.get('reglas', {})
    regla = None
    votante_norm = normalizar(votante)
    for nombre, tipo in reglas.items():
        if normalizar(nombre) == votante_norm:
            regla = tipo
            break

    normal = float(str(valores.get('valor_normal', 1)).replace(',', '.'))
    if regla == 'negativo':
        return -1
    if regla == 'doble':
        return normal * 2
    if regla == 'medio':
        return 0.5
    if regla is not None and regla != 'normal':
        # Las reglas numéricas son valores fijos (por ejemplo 0.5, 3 o -1).
        try:
            return float(str(regla).replace(',', '.'))
        except (TypeError, ValueError):
            pass
    return normal


def numero_texto(valor):
    valor = float(valor)
    if valor.is_integer():
        return str(int(valor))
    return f'{valor:g}'


def contar_votos():
    votos = cargar_votos()
    vivos = obtener_vivos()
    valores = cargar_valores()
    resultado = {}
    cantidad = 0
    for votante, datos in votos.items():
        votante_n = normalizar(votante)
        if votante_n not in vivos:
            continue
        objetivo = datos.get('objetivo') if isinstance(datos, dict) else datos
        objetivo_n = normalizar(objetivo)
        if objetivo_n not in vivos:
            continue
        objetivo_real = vivos[objetivo_n]
        puntos = valor_emitido(vivos[votante_n], valores)
        resultado.setdefault(objetivo_real, []).append((vivos[votante_n], puntos))
        cantidad += 1
    return resultado, cantidad


def ordenar_recuento():
    resultado, cantidad = contar_votos()
    puntuaciones = {objetivo: sum(puntos for _, puntos in lista) for objetivo, lista in resultado.items()}
    return sorted(resultado.items(), key=lambda x: (-puntuaciones[x[0]], x[0].casefold())), cantidad


def calcular_mayoria():
    return math.floor(len(obtener_vivos()) / 2) + 1


def jugadores_sin_votar():
    vivos = obtener_vivos()
    votos = cargar_votos()
    votantes = {normalizar(n) for n in votos if normalizar(n) in vivos}
    return sorted((nombre for clave, nombre in vivos.items() if clave not in votantes), key=str.casefold)


def generar_texto():
    resultado, cantidad = ordenar_recuento()
    vivos = obtener_vivos()
    puntuaciones = {
        objetivo: sum(puntos for _, puntos in lista)
        for objetivo, lista in resultado
    }

    texto = [
        '[B]RECUENTO DE VOTOS[/B]',
        f'Jugadores vivos: {len(vivos)}',
        f'Mayoría necesaria: {calcular_mayoria()} votos emitidos',
        f'Votos válidos: {cantidad}',
    ]

    if not resultado:
        texto.append('No hay votos válidos.')
    else:
        for jugador, votantes in resultado:
            total = puntuaciones[jugador]
            total_txt = numero_texto(total)
            etiqueta = 'voto' if abs(total) == 1 else 'votos'
            nombres = ' '.join(
                f'- {votante}'
                for votante, _ in sorted(votantes, key=lambda x: x[0].casefold())
            )
            texto.append(f'[B]{jugador} ({total_txt} {etiqueta})[/B] {nombres}'.rstrip())

    sin_votar = jugadores_sin_votar()
    if sin_votar:
        texto.append('[B]Sin votar:[/B] ' + ' '.join(f'- {j}' for j in sin_votar))

    return '\n'.join(texto)


def actualizar_recuento():
    texto = generar_texto()
    ARCHIVO_RECUENTO.write_text(texto, encoding='utf-8')
    if DEBUG:
        print('Recuento actualizado.')
    return texto
